@extends('applications.layout')
  
@section('content')
<div class="add">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="text-center">
            <h2>Add New Item</h2>
        </div>
        <div class="text-center">
            <a class="btn btn-outline-light" href="{{ route('applications.index') }}"> Back</a>
        </div>
    </div>
</div>
   
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong>Invalid input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
   
<form action="{{ route('applications.store') }}" method="POST">
    @csrf
  
      <div class="row ">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text-center" name="name" class="form-control" placeholder="Name">
            </div>
        </div>
        
        <div class="row">
            <div class="form-group">
                <strong>Quantity:</strong>
                    <input type="text-center" name="quantity" class="form-control" placeholder="Quantity">
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <strong>Detail:</strong>
                <input type="text-center" name="detail" class="form-control" placeholder="Details">
            </div>
        </div>
   
        <div class="text-center">
                <button type="submit" class="btn btn-outline-light">Submit</button>
        </div>
    </div>
   
</form>
@endsection