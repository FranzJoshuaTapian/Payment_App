@extends('applications.layout')
 
@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="text-center">
            <h2><i class="fas fa-coins"></i></i>Payment Application</h2>
                    <p >List of Pending Payments</p>
            </div>
            <div class="text-center">
                <a class="btn btn-outline-light " href="{{ route('applications.create') }}"> Add New Item</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-primary">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="border"></div>
    <table class="table table-dark table-striped table-hover ">
            <tr>
                <th >#</th>
                <th>Name</th>
                <th >Details</th>
                <th >Quantity</th>
                <th width="280px" >Action</th>
            </tr>
      
        @foreach ($applications as $application)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $application->name }}</td>
            <td>{{ $application->detail }}</td>    
            <td>{{ $application->quantity }}</td> 
            <td>
                <form action="{{ route('applications.destroy',$application->id) }}" method="POST">
       
                    <a href="{{ route('applications.show', $application->id) }}" title="show">
                            <i class="fas fa-eye text-light fa-lg"></i></a>
                     
                    <a href="{{ route('applications.edit', $application->id) }}">
                            <i class="fas fa-edit text-light fa-lg"></i></a>
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-light"></i></button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $applications->links() !!}
      
@endsection